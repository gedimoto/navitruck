precision mediump float;
uniform vec4 Ucolor;
uniform vec2 uBuildingParams;

void main() 
{
	vec4 col = Ucolor;
	col.a = uBuildingParams.x;
	gl_FragColor = col;
}
