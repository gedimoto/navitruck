precision mediump float;
//uniform vec4 Ucolor;
uniform sampler2D texture;
uniform vec2 uBuildingParams;

varying vec2 v_txCoor;

void main()
{
	vec4 col = texture2D( texture, v_txCoor );
	if( col.a < 0.5 )
		discard;

	col.a = col.a * uBuildingParams.x;
	gl_FragColor = col;
}
