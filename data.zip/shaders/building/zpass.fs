precision mediump float;

void main() 
{
	gl_FragColor = vec4(1.,1.,1.,1.);
}
