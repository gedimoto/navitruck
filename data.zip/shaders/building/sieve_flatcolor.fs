precision mediump float;

uniform vec4 Ucolor;
uniform vec2 uBuildingParams;
uniform sampler2D texture2;

varying vec2 v_txCoor;

void main() 
{
	if( floor(mod(gl_FragCoord.x+gl_FragCoord.y+1., 2.)) < 0.9 )
		discard;

	float warp = texture2D( texture2, v_txCoor.xy ).a;	
	if( warp > uBuildingParams.y )
		discard;

	gl_FragColor.rgb = Ucolor.rgb;
	gl_FragColor.a = 1.; 
}
