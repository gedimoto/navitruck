precision mediump float;

varying vec3 v_normal;

void main()
{
	gl_FragColor.rgb = v_normal/2.  + vec3(0.5);
	gl_FragColor.a = 1.;
}
