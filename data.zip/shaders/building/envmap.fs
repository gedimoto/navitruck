precision mediump float;

uniform vec2 uBuildingParams;

uniform sampler2D texture;

varying vec2 v_tx;
varying vec3 v_color;

void main() 
{
	vec4 col = texture2D( texture, v_tx );
	col.rgb += v_color;
	col.a = uBuildingParams.x;
	gl_FragColor = col;
}
