precision mediump float;
varying vec4 v_color;
uniform vec2 uBuildingParams;

void main() 
{
	vec4 col = v_color;
	col.a = uBuildingParams.x;
	gl_FragColor = col;
}
