precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec2 uBuildingParams;

void main()
{		
	vec4 col = texture2D( texture, v_txCoor );
	if( col.a < 0.5 )
		discard;

	col.a = uBuildingParams.x;
	gl_FragColor = col;
}
