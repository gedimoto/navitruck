precision mediump float;
//uniform vec4 Ucolor;
uniform sampler2D texture;
uniform vec2 uBuildingParams;

varying vec2 v_txCoor;

void main() 
{		
	vec3 tx = texture2D( texture, v_txCoor ).rgb;
	float gray = (tx.r+tx.g+tx.b) / 3.;

	gl_FragColor.rgb = mix( tx, vec3(gray,gray,gray), 1.-uBuildingParams.x );
	gl_FragColor.a = uBuildingParams.x;
}
