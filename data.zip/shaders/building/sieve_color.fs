precision mediump float;

uniform vec2 uBuildingParams;
uniform sampler2D texture2;

varying vec4 v_color;
varying vec2 v_txCoor;


void main() 
{
	float a = step( 0.9, floor(mod(gl_FragCoord.x+gl_FragCoord.y+1., 2.) ));
	float warp = texture2D( texture2, v_txCoor.xy ).a;
	float b = step( uBuildingParams.y, warp );

	if( a+b > 0. )
		discard;

	gl_FragColor = v_color;
	gl_FragColor.rgb = vec3(1,0,0);

	gl_FragColor.a = 1.;
}
