precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;

void main()
{		
	vec4 col = texture2D( texture, v_txCoor );
	if( col.a < 0.5 )
		discard;

	gl_FragColor = vec4(1.,1.,1.,1.);
}
