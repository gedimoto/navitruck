precision mediump float;

varying vec2 v_txCoor;
varying vec3 v_normal;
uniform sampler2D texture;

void main()
{
	vec4 col = texture2D( texture, v_txCoor );
	if( col.a < 0.5 )
		discard;

	gl_FragColor.rgb = v_normal/2.  + vec3(0.5);
	gl_FragColor.a = 1.;
}
