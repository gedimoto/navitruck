precision mediump float;

varying vec3 v_txCoor;
uniform sampler2D texture;
//uniform sampler2D texture2;
uniform vec3 Ucolor;
uniform vec4 U_V4_1; 		// width params

void main()
{
	vec2 tx = v_txCoor.zy;
	tx.x *= U_V4_1.x * 3.;
	vec4 color = texture2D( texture, tx.xy );
	gl_FragColor.rgb = color.rgb * Ucolor;

	//blending of the line endings
	//float blend = texture2D( texture, v_txCoor.xy ).a;
	//blend *= color.r;
	gl_FragColor.a = color.r;
}
