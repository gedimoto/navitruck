precision mediump float;

void main()
{
	gl_FragColor.x = 1.;
	gl_FragColor.y = 1.;
	gl_FragColor.z = 1.;
	gl_FragColor.w = 1.;
}
