precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec4 Ucolor;

float Luminosity( vec3 color )
{
	return 0.299 * color.r + 0.587 * color.g + 0.114 * color.b;
}

void main()
{
	vec4 color = texture2D( texture, v_txCoor ) * vec4(1.0, 1.0, 1.0, Ucolor.a);

	if (Ucolor.r < 0.0)
	{
		color.rgb = Ucolor.rgb;
	}
	else
	{
		float lum = Luminosity(color.rgb);

		// colorize
		color.rgb = (Ucolor.rgb * lum) / 2.0;

		// now the trick
		float col_lum = Luminosity(Ucolor.rgb);
		if (col_lum > lum)
		{
			color.r = min(color.r + Ucolor.r / 4.0, 1.0);
			color.g = min(color.g + Ucolor.g / 4.0, 1.0);
			color.b = min(color.b + Ucolor.b / 4.0, 1.0);
		}
	}

	gl_FragColor = color;
}