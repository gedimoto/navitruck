precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec4 Ucolor;

void main()
{
	gl_FragColor = texture2D( texture, v_txCoor ) * Ucolor;
}
