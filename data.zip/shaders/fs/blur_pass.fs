precision mediump float;

uniform sampler2D texture;

varying vec2 v_texCoor0;
varying vec2 v_texCoor1;
varying vec2 v_texCoor2;
varying vec2 v_texCoor3;

void main()
{
	gl_FragColor = 
		0.09 * texture2D( texture, v_texCoor0 ) +
		0.41 * texture2D( texture, v_texCoor1 ) +
		0.41 * texture2D( texture, v_texCoor2 ) +
		0.09 * texture2D( texture, v_texCoor3 );
}
