precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec4 Ucolor;

void main()
{
	vec4 color = texture2D( texture, v_txCoor ) * Ucolor;
	gl_FragColor.x = gl_FragColor.y = gl_FragColor.z = 0.299 * color.x + 0.587 * color.y + 0.114 * color.z;
	gl_FragColor.w = color.w;
}