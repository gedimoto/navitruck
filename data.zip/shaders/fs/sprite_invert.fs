precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec4 Ucolor;

void main()
{
	gl_FragColor = vec4(1.0, 1.0, 1.0, 0.0) - texture2D( texture, v_txCoor ) * vec4(1.0, 1.0, 1.0, -Ucolor.a);
}